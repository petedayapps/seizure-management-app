# Seizure Management App Prototype

This is a functional prototype for a paediatric seizure management app built as a web application using React.

## Features

- **Patient Input:** Capture seizure onset (relative or absolute), patient weight (or age if unknown), and known epileptic status.
- **Dynamic Dashboard:** Displays elapsed time since seizure onset, calculates drug doses, and shows an action checklist with countdown timers based on the guideline algorithm.
- **Action Checklist:** Steps include administering first and second benzodiazepine doses, levetiracetam, and escalation to additional medication/RSI.
- **Next-Step Prompts:** Highlights the next available action based on elapsed time and completed actions.

## Deployment

Simply push this repository to GitHub and deploy using a service such as [Vercel](https://vercel.com/) or [Netlify](https://www.netlify.com/). No additional local terminal work is required.
