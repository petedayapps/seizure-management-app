export function estimateWeight(age) {
  // Simple weight estimation formula: weight = (age * 2) + 8
  if (age <= 0) {
    throw new Error("Age must be a positive number");
  }
  return (age * 2) + 8;
}

export function calculateDoses(weight) {
  if (weight <= 0) {
    throw new Error("Weight must be a positive number");
  }
  // Calculate drug doses based on weight:
  const midazolamDose = Math.min(weight * 0.3, 10); // mg
  const lorazepamDose = Math.min(weight * 0.1, 4);  // mg
  const levetiracetamDose = Math.min(weight * 40, 3000); // mg
  return {
    midazolam: midazolamDose.toFixed(2),
    lorazepam: lorazepamDose.toFixed(2),
    levetiracetam: levetiracetamDose.toFixed(2)
  };
}