import React, { useState } from 'react';
import InputForm from './components/InputForm';
import Dashboard from './components/Dashboard';

function App() {
  const [patientData, setPatientData] = useState(null);

  return (
    <div className="App">
      <header>
        <h1>Paediatric Seizure Management App</h1>
      </header>
      {!patientData ? (
        <InputForm onSubmit={setPatientData} />
      ) : (
        <Dashboard patientData={patientData} />
      )}
    </div>
  );
}

export default App;
