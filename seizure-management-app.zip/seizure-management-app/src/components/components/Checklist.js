import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

const initialSteps = [
  { id: 1, name: "Administer first BDZ dose", offset: 300, completedTime: null },
  { id: 2, name: "Administer second BDZ dose", offset: 300, completedTime: null },
  { id: 3, name: "Administer Levetiracetam", offset: 300, completedTime: null },
  { id: 4, name: "Proceed to additional medication / RSI", offset: 600, completedTime: null }
];

function Checklist({ seizureStart }) {
  const [steps, setSteps] = useState(initialSteps);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const markComplete = (stepId) => {
    const updatedSteps = steps.map((step) => {
      if (step.id === stepId) {
        return { ...step, completedTime: now };
      }
      return step;
    });
    setSteps(updatedSteps);
  };

  const getAvailableTime = (step, index) => {
    if (index === 0) {
      return new Date(seizureStart.getTime() + step.offset * 1000);
    } else {
      const previousStep = steps[index - 1];
      if (previousStep.completedTime) {
        return new Date(previousStep.completedTime.getTime() + step.offset * 1000);
      } else {
        return null;
      }
    }
  };

  const formatTimeDiff = (diffInSeconds) => {
    const m = Math.floor(diffInSeconds / 60);
    const s = diffInSeconds % 60;
    return `${m} min ${s} sec`;
  };

  return (
    <div>
      <h3>Action Checklist</h3>
      {steps.map((step, index) => {
        const availableTime = getAvailableTime(step, index);
        let isAvailable = false;
        let countdown = null;
        if (availableTime) {
          const diff = Math.floor((availableTime - now) / 1000);
          if (diff <= 0) {
            isAvailable = true;
          } else {
            countdown = formatTimeDiff(diff);
          }
        }
        const isCompleted = step.completedTime !== null;

        return (
          <div key={step.id} className={`checklist-item ${isAvailable && !isCompleted ? 'active' : ''}`}>
            <p>{step.name}</p>
            {availableTime && !isAvailable && (
              <p>Available in: {countdown}</p>
            )}
            {isCompleted && (
              <p>Completed at: {step.completedTime.toLocaleTimeString()}</p>
            )}
            {isAvailable && !isCompleted && (
              <button className="complete-btn" onClick={() => markComplete(step.id)} aria-label={`Mark ${step.name} as complete`}>
                Mark as Complete
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}

Checklist.propTypes = {
  seizureStart: PropTypes.instanceOf(Date).isRequired,
};

export default Checklist;