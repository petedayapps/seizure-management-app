import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { calculateDoses } from '../utils';
import Checklist from './Checklist';

function Dashboard({ patientData }) {
  const { seizureStart, weight } = patientData;
  const doses = calculateDoses(weight);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const seizureStartDate = new Date(seizureStart);
  const elapsedSeconds = Math.floor((currentTime - seizureStartDate) / 1000);

  return (
    <div className="dashboard">
      <h2>Patient Dashboard</h2>
      <p>
        <strong>Seizure Start:</strong> {seizureStartDate.toLocaleString()}
      </p>
      <p>
        <strong>Elapsed Time:</strong> {Math.floor(elapsedSeconds / 60)} min {elapsedSeconds % 60} sec
      </p>
      <h3>Calculated Drug Doses</h3>
      <ul>
        <li>Midazolam: {doses.midazolam} mg</li>
        <li>Lorazepam: {doses.lorazepam} mg</li>
        <li>Levetiracetam: {doses.levetiracetam} mg</li>
      </ul>
      <Checklist seizureStart={seizureStartDate} />
    </div>
  );
}

Dashboard.propTypes = {
  patientData: PropTypes.shape({
    seizureStart: PropTypes.string.isRequired,
    weight: PropTypes.number.isRequired,
  }).isRequired,
};

export default Dashboard;