import React, { useState } from 'react';
import { estimateWeight } from '../utils';

function InputForm({ onSubmit }) {
  const [seizureTimeType, setSeizureTimeType] = useState('relative');
  const [relativeTime, setRelativeTime] = useState('');
  const [absoluteTime, setAbsoluteTime] = useState('');
  const [weight, setWeight] = useState('');
  const [age, setAge] = useState('');
  const [knownEpileptic, setKnownEpileptic] = useState(false);
  const [seizurePlan, setSeizurePlan] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    let seizureStart;
    if (seizureTimeType === 'relative') {
      // Assume current time minus relativeTime (in minutes)
      seizureStart = new Date(Date.now() - Number(relativeTime) * 60000);
    } else {
      seizureStart = new Date(absoluteTime);
    }

    let finalWeight = weight;
    if (!finalWeight && age) {
      finalWeight = estimateWeight(Number(age));
    }

    onSubmit({
      seizureStart,
      weight: Number(finalWeight),
      age: Number(age),
      knownEpileptic,
      seizurePlan
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Seizure Onset Type:</label>
        <select value={seizureTimeType} onChange={(e) => setSeizureTimeType(e.target.value)}>
          <option value="relative">Relative (minutes since onset)</option>
          <option value="absolute">Absolute (time of onset)</option>
        </select>
      </div>
      {seizureTimeType === 'relative' ? (
        <div className="form-group">
          <label>Minutes since seizure onset:</label>
          <input
            type="number"
            value={relativeTime}
            onChange={(e) => setRelativeTime(e.target.value)}
            required
          />
        </div>
      ) : (
        <div className="form-group">
          <label>Time of seizure onset:</label>
          <input
            type="datetime-local"
            value={absoluteTime}
            onChange={(e) => setAbsoluteTime(e.target.value)}
            required
          />
        </div>
      )}
      <div className="form-group">
        <label>Patient Weight (kg):</label>
        <input
          type="number"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          placeholder="Leave blank if unknown"
        />
      </div>
      <div className="form-group">
        <label>Patient Age (years):</label>
        <input
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          placeholder="Used if weight unknown"
        />
      </div>
      <div className="form-group">
        <label>Known Epileptic?</label>
        <input
          type="checkbox"
          checked={knownEpileptic}
          onChange={(e) => setKnownEpileptic(e.target.checked)}
        />
      </div>
      {knownEpileptic && (
        <div className="form-group">
          <label>Personalised Seizure Plan (URL or note):</label>
          <input
            type="text"
            value={seizurePlan}
            onChange={(e) => setSeizurePlan(e.target.value)}
          />
        </div>
      )}
      <button type="submit">Start Management</button>
    </form>
  );
}

export default InputForm;